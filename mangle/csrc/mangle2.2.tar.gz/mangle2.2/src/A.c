I foil rm *.c
